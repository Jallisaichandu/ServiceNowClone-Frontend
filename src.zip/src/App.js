import React, { useState } from "react";

import "./App.css";

import Dashboard from "./components/Dashboard";
import Users from "./components/Users";
import Tickets from "./components/Tickets";
import Login from "./components/Login";
import Navbar from "./components/Navbar";

function App() {

  const [page, setPage] = useState("dashboard");

  const [loggedIn, setLoggedIn] = useState(
    localStorage.getItem("loggedIn") === "true"
  );

  const logout = () => {
    localStorage.removeItem("loggedIn");
    localStorage.removeItem("token"); 
    setLoggedIn(false);
  };

  if (!loggedIn) {
    return (
      <Login onLogin={() => setLoggedIn(true)} />
    );
  }

  return (
    <div className="container">

      <div className="sidebar">

        <h2>ServiceNow</h2>

        <ul>
          <li onClick={() => setPage("dashboard")}>Dashboard</li>
          <li onClick={() => setPage("users")}>Users</li>
          <li onClick={() => setPage("tickets")}>Tickets</li>
          <li onClick={logout}>Logout</li>
        </ul>

      </div>

      <div className="content">

        <Navbar />


        {page === "dashboard" ? <Dashboard /> : null}

        {page === "users" ? <Users /> : null}

        {page === "tickets" ? <Tickets /> : null}

      </div>
     
    </div>
  );
}

export default App;