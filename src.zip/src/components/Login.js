import React, { useState } from "react";
import API from "../services/api";

function Login({ onLogin }) {

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = () => {

  API.post("/auth/login", {
    email,
    password
  })
  .then((response) => {
    localStorage.setItem("loggedIn", "true");
    localStorage.setItem("token", response.data.token);

    onLogin();

  })
  .catch(() => {

    alert("Invalid Email or Password");

  });

};

  return (
    <div
      style={{
        width: "400px",
        margin: "100px auto",
        padding: "20px",
        background: "white",
        borderRadius: "10px"
      }}
    >
      <h2>Login</h2>

      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />

      <br /><br />

      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />

      <br /><br />

      <button onClick={handleLogin}>
        Login
      </button>

    </div>
  );
}

export default Login;