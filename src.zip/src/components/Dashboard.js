import React, { useEffect, useState } from "react";
import API from "../services/api";

import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend
} from "chart.js";

import { Doughnut } from "react-chartjs-2";

ChartJS.register(
  ArcElement,
  Tooltip,
  Legend
);

function Dashboard() {

  const [users, setUsers] = useState([]);
  const [tickets, setTickets] = useState([]);

  useEffect(() => {

    API.get("/users")
      .then(res => setUsers(res.data));

    API.get("/tickets")
      .then(res => setTickets(res.data));

  }, []);

  const openTickets =
    tickets.filter(t => t.status === "OPEN").length;

  const closedTickets =
    tickets.filter(t => t.status === "CLOSED").length;

  const chartData = {
    labels: ["Open", "Closed"],
    datasets: [
      {
        data: [openTickets, closedTickets],
        backgroundColor: [
          "#f39c12",
          "#2ecc71"
        ]
      }
    ]
  };

  return (

    <div>

      <h2>Dashboard</h2>

      <div className="dashboard-cards">

        <div className="dashboard-card">
          <h3>Total Users</h3>
          <h2>{users.length}</h2>
        </div>

        <div className="dashboard-card">
          <h3>Total Tickets</h3>
          <h2>{tickets.length}</h2>
        </div>

        <div className="dashboard-card">
          <h3>Open Tickets</h3>
          <h2>{openTickets}</h2>
        </div>

        <div className="dashboard-card">
          <h3>Closed Tickets</h3>
          <h2>{closedTickets}</h2>
        </div>

      </div>
     <div className="dashboard-content">

    <div className="chart-card">

        <h3>Ticket Status Overview</h3>

        <div className="chart-container">

            <Doughnut
                data={chartData}
                options={{
                    responsive: true,
                    maintainAspectRatio: false
                }}
            />

        </div>

    </div>

    <div className="stats-card">

        <h3>Quick Statistics</h3>

        <p><strong>Total Users:</strong> {users.length}</p>

        <p><strong>Total Tickets:</strong> {tickets.length}</p>

        <p><strong>Open Tickets:</strong> {openTickets}</p>

        <p><strong>Closed Tickets:</strong> {closedTickets}</p>

    </div>

</div>

    </div>

  );
}

export default Dashboard;