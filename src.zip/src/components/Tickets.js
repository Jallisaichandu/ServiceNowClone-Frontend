import React, { useEffect, useState } from "react";
import API from "../services/api";

function Tickets() {

  const [tickets, setTickets] = useState([]);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState("LOW");

  const [search, setSearch] = useState("");

  useEffect(() => {
    loadTickets();
  }, []);

  const loadTickets = () => {
    API.get("/tickets")
      .then((response) => {
        setTickets(response.data);
      })
      .catch((error) => {
        console.error(error);
      });
  };

  const createTicket = () => {

    const ticket = {
      title,
      description,
      priority,
      status: "OPEN"
    };

    API.post("/tickets", ticket)
      .then(() => {

        alert("Ticket Created Successfully");

        setTitle("");
        setDescription("");
        setPriority("LOW");

        loadTickets();
      })
      .catch((error) => {
        console.error(error);
      });
  };

  const deleteTicket = (id) => {

    if (window.confirm("Are you sure you want to delete this ticket?")) {

      API.delete(`/tickets/${id}`)
        .then(() => {
          loadTickets();
        })
        .catch((error) => {
          console.error(error);
        });
    }
  };

  const closeTicket = (ticket) => {

    const updatedTicket = {
      ...ticket,
      status: "CLOSED"
    };

    API.put(`/tickets/${ticket.id}`, updatedTicket)
      .then(() => {
        loadTickets();
      })
      .catch((error) => {
        console.error(error);
      });
  };

  return (
    <div style={{ padding: "20px" }}>

      <h2>Ticket Management</h2>

      <h3>Create Ticket</h3>

      <input
        type="text"
        placeholder="Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />

      <br /><br />

      <textarea
        placeholder="Description"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
      />

      <br /><br />

      <select
        value={priority}
        onChange={(e) => setPriority(e.target.value)}
      >
        <option value="LOW">LOW</option>
        <option value="MEDIUM">MEDIUM</option>
        <option value="HIGH">HIGH</option>
      </select>

      <br /><br />

      <button onClick={createTicket}>
        Create Ticket
      </button>

      <hr />

      <h3>Search Tickets</h3>

      <input
        type="text"
        placeholder="Search by Title"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      <br /><br />
      <input
  type="text"
  placeholder="Search Tickets..."
  value={search}
  onChange={(e) => setSearch(e.target.value)}
  className="search-box"
/>

<br /><br />

      <table border="1" cellPadding="10">

        <thead>
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Description</th>
            <th>Priority</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>

        <tbody>

         {tickets
  .filter((ticket) =>
    ticket.title.toLowerCase().includes(search.toLowerCase()) ||
    ticket.description.toLowerCase().includes(search.toLowerCase())
  )
  .map((ticket) => (

              <tr key={ticket.id}>
                <td>{ticket.id}</td>
                <td>{ticket.title}</td>
                <td>{ticket.description}</td>
                <td>
                
  <span
    className={
      ticket.priority === "HIGH"
        ? "priority-high"
        : ticket.priority === "MEDIUM"
        ? "priority-medium"
        : "priority-low"
    }
  >
    {ticket.priority}
  </span>
</td>
                <td>
                
  <span
    className={
      ticket.status === "OPEN"
        ? "status-open"
        : "status-closed"
    }
  >
    {ticket.status}
  </span>
</td>

                <td>

                  {ticket.status !== "CLOSED" && (
                    <button
                      onClick={() => closeTicket(ticket)}
                    >
                      Close
                    </button>
                  )}

                  {" "}

                  <button
                    onClick={() => deleteTicket(ticket.id)}
                  >
                    Delete
                  </button>

                </td>

              </tr>

            ))}

        </tbody>

      </table>

    </div>
  );
}

export default Tickets;